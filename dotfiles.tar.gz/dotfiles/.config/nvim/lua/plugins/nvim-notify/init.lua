return {
  {
    "rcarriga/nvim-notify",
    opts = {
      render = "minimal",
      stages = "slide",
      timeout = 2000,
      maximum_width = 0.5,
      maximum_height = 0.2,
    },
  }
}
