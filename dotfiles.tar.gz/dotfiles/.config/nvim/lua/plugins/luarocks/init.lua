return {
  {
    "vhyrro/luarocks.nvim",
    priority = 1000,
    config = true,
  }
}
