return {
  {
    "nathangrigg/vim-beancount",
    ft = "beancount",
  }
}
