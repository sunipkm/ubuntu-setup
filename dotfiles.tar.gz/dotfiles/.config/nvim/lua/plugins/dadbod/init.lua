return {
  {'tpope/vim-dadbod'},
  {'kristijanhusak/vim-dadbod-ui'},
  {'kristijanhusak/vim-dadbod-completion'},
}
